import React from 'react';
import TaskTracker from './components/TaskTracker';

const App = () => {
  return (
    <div>
      <TaskTracker />
    </div>
  );
};

export default App;
